import netmiko
import re


class Switch:
    def __init__(self, name, mgmtIP, vlans, portConfig):
        self.name = name
        self.mgmtIP = mgmtIP
        self.vlans = vlans
        self.portConfig = portConfig
        self.session = self.createSession()

        self.missingVLANs = []
        self.extraVLANs = []
        self.misconfiguredPorts = {}

    def createSession(self):
        return netmiko.ConnectHandler(device_type="cisco_nxos", ip=self.mgmtIP, username="admin", password="cisco")

    def validateVLANDatabase(self):
        results = [re.findall(r"^[0-9]+", result) for result in self.session.send_command("show vlan br | include ^[0-9]").split("\n")]
        vlanList = [int(vlan[0]) for vlan in results if vlan != []]

        for vlan in self.vlans:
            if vlan not in vlanList:
                self.missingVLANs.append(vlan)

        for vlan in vlanList:
            if vlan not in self.vlans:
                self.extraVLANs.append(vlan)

        if self.missingVLANs is not None:
            self.missingVLANs = str(self.missingVLANs)[1:-1]
        if self.extraVLANs is not None:
            self.extraVLANs = str(self.extraVLANs)[1:-1]

        return [self.missingVLANs, self.extraVLANs]

    def validateAccessPorts(self):
        for port in self.portConfig:
            results = self.session.send_command(f"show interface {port} switchport | include Access")
            portVLAN = int(re.search(r"\b[0-9]+\b", results).group())

            if portVLAN != self.portConfig[port]:
                self.misconfiguredPorts[port] = portVLAN

        return self.misconfiguredPorts


globalVLANs = [1, 10, 20, 30]

N9300v01 = Switch(name="N9300v-01", mgmtIP="172.16.176.24", vlans=globalVLANs, portConfig={"Eth1/1": 10, "Eth1/2": 20, "Eth1/3": 30})
N9300v02 = Switch(name="N9300v-02", mgmtIP="172.16.176.23", vlans=globalVLANs, portConfig={"Eth1/1": 20, "Eth1/2": 20, "Eth1/3": 30})
N9300v03 = Switch(name="N9300v-03", mgmtIP="172.16.176.25", vlans=[1, 10, 30], portConfig={"Eth1/1": 10, "Eth1/2": 10, "Eth1/3": 30})

switchObjects = [N9300v01, N9300v02, N9300v03]

for switch in switchObjects:
    misconfigVLANs = switch.validateVLANDatabase()
    misconfigPorts = switch.validateAccessPorts()

    print(f"------ {switch.name} ------")
    print(f"Missing VLANs: {misconfigVLANs[0]}")
    print(f"Extra VLANs: {misconfigVLANs[1]}")

    for port in misconfigPorts.keys():
        print(f"Misconfigured Port: {port}, Intended VLAN: {switch.portConfig[port]}, Configured VLAN: {misconfigPorts[port]}")
