"""
REQUIREMENTS FOR CHALLENGE 1:

1. The script must process user-defined shop properties (e.g., name and item details) from the 11-shopitems.json file.
2. The script must present an overall catalog of items to the user. The item’s ID,  name, net price, and available quantity must be shown. All items must be shown. This main interface must also show the store name. Ensure that all prices in the script are shown with two decimal places only; rounding to the nearest cent is acceptable, but not recommended.
3. The script must implement a shopping cart construct that saves the user's desired item and quantity choice. The cart must allow users to remove items. Items must be available (quantity > 0) to be added to the shopping cart and the quantity desired must not exceed the quantity that is available for an item. Users must be able to view the shopping cart and the net price of all of the items in the shopping cart.
4. The script must account for sales tax and any discounts (0 - 100%) present on an item. For simplicity, assume that all sales tax, regardless of location, is assessed at 5%.
5. The script must provide a mechanism to collect a user's information and save all information, including the user's cart, to the 11-shopRequests.csv file. The user must be prompted to provide their full name, e-mail address, phone number, country code (e.g., US, CA, NZ, AU), and mailing address. The user's cart must not be empty when completing the purchase.
6. The script must modify the 11-shopitems.json file to reflect the change in quantity after the item has been purchased.

"""