import netmiko
from time import sleep

""" DISCLAIMER: This is a deliberately suboptimal and inefficient script. This base script serves to
demonstrate the capabilities of Netmiko using basic Python constructs. In future labs, you will explore
and practice methods for optimizing the code below to create a more efficient script for managing devices via SSH. """

# Define IP addresses for CSRs
CSR1IP = None
CSR2IP = None
CSR3IP = None

# Create CSR SSH Sessions
CSR1Session = None
CSR2Session = None
CSR3Session = None

# Print "CSR-1: "

# Return show ip interface brief output

# Enter global config mode

# Configure GigabitEthernet2 IP address (10.0.1.1/24) and bring up interface

# Configure Loopback0 IP address (1.1.1.1/32)

# Advertise all IP-enabled interfaces in OSPF

# Exit global config mode


# Print "CSR-2: "

# Return show ip interface brief output

# Enter global config mode

# Configure GigabitEthernet2 IP address (10.0.2.1/24) and bring up interface

# Configure Loopback0 IP address (2.2.2.2/32)

# Advertise all IP-enabled interfaces in OSPF

# Exit global config mode


# Print "CSR-3: "

# Return show ip interface brief output

# Enter global config mode

# Configure GigabitEthernet2 IP address (10.0.3.1/24) and bring up interface

# Configure Loopback0 IP address (3.3.3.3/32)

# Advertise all IP-enabled interfaces in OSPF

# Exit global config mode

# Wait 60 seconds before running show commands to allow OSPF adjacencies to come up and converge


# Print "CSR-1"

# Print interface IP addresses, OSPF adjacency tables, and routing tables for CSR-1

# Disconnect the CSR-1 SSH session

# Print "CSR-2"

# Print interface IP addresses, OSPF adjacency tables, and routing tables for CSR-2

# Disconnect the CSR-2 SSH session

# Print "CSR-3"

# Print interface IP addresses, OSPF adjacency tables, and routing tables for CSR-3

# Disconnect the CSR-3 SSH session

print("Finished!")