import netmiko
from time import sleep
import getpass
import re


def importCSRs(fileName=""):
    CSRIPs = []
    try:
        with open(fileName, "r") as CSRList:
            CSRIPs = [CSR.rstrip("\n") for CSR in CSRList.readlines()]
            return CSRIPs
    except FileNotFoundError:
        numCSRs = int(input("How many CSRs are there?: "))
        index = 0
        while index < numCSRs:
            CSRIPs.append(input(f"Provide the IP address of CSR {index + 1}: "))
            index += 1
        return CSRIPs


def getCSRCredentials():
    username = input("Device Username: ")
    password = getpass.getpass("Device Password: ")
    return (username, password)


class CSR:
    def __init__(self, ip, username, password, number):
        self.ip = ip
        self.username = username
        self.password = password
        self.number = number
        self.configurationLog = ""
        self.session = self.createSSHSession()

    def createSSHSession(self):
        try:
            return netmiko.ConnectHandler(device_type="cisco_xe", ip=self.ip, username=self.username, password=self.password)
        except netmiko.exceptions.NetmikoTimeoutException:
            return None
        except netmiko.exceptions.NetmikoAuthenticationException:
            return None

    def configureDevice(self, configSet):
        operationalConfig = self.session.send_command(f"show run all | s {configSet[0]}").split("\n ")
        configSent = False

        for statement in configSet:
            if statement not in operationalConfig:
                self.session.send_config_set(configSet)
                self.configurationLog += f"Configuration {configSet} sent to CSR-{str(self.number)}\n"
                configSent = True
                break

        if not configSent:
            self.configurationLog += f"Configuration {configSet} not sent to CSR-{str(self.number)}\n"
            return False

        return True

    def displayCommandOutput(self, command):
        print(f"CSR-{str(self.number)}: ")
        print(self.session.send_command(command))

    def checkConvergence(self):
        ospfNeighbors = [re.findall(r"\b[A-Z0-9]+\/[A-Z]+\b", neighbor)[0] for neighbor in
                         self.session.send_command("show ip ospf neighbor | include ^[0-9]").split("\n")
                         if neighbor != ""]
        if len(ospfNeighbors) == 0:
            return False
        if len(ospfNeighbors) > 0:
            for neighbor in ospfNeighbors:
                if neighbor not in ["FULL/BDR", "FULL/DR", "FULL/DROTHER", "2WAY/DROTHER"]:
                    return False

        return True

    def disconnectSession(self):
        self.session.disconnect()

    def writeLog(self, fileName):
        with open(fileName, "a") as actionLog:
            actionLog.write(self.configurationLog)


CSRObjects = []
CSRIPs = importCSRs("6-CSR.txt")
credentials = getCSRCredentials()

for address in CSRIPs:
    CSRObjects.append(CSR(ip=address, username=credentials[0], password=credentials[1], number=CSRIPs.index(address) + 1))

for CSR in CSRObjects:
    if CSR.session is None:
        CSRObjects.remove(CSR)
        continue
    # Return show ip interface brief output
    CSR.displayCommandOutput("show ip interface brief")

    configurations = [["interface GigabitEthernet2", "no shutdown", f"ip address 10.0.{str(CSR.number)}.1 255.255.255.0"],
                      ["interface Loopback0", f"ip address {str(CSR.number)}.{str(CSR.number)}.{str(CSR.number)}.{str(CSR.number)} 255.255.255.255"],
                      ["router ospf 1", "network 0.0.0.0 255.255.255.255 area 0"]]

    for configuration in configurations:
        configStatus = CSR.configureDevice(configuration)

    CSR.writeLog("7-actionlog.txt")

# Check convergence
sleep(40)
for CSR in CSRObjects:
    sleepCounter = 40
    while True:
        if CSR.checkConvergence():
            break
        else:
            if sleepCounter < 60:
                sleep(5)
                sleep += 5
            else:
                break
    # Return interface IP addresses, OSPF adjacency tables, and routing tables for each router
    CSR.displayCommandOutput("show ip int br")
    CSR.displayCommandOutput("show ip route")
    CSR.displayCommandOutput("show ip ospf neighbor")

print("Finished!")