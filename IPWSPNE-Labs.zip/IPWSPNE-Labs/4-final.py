import re
import json

with open("4-registrationdata.json", "r") as data:
    registrationData = json.load(data)["registrations"]

emailValidRegex = r"^\w(\w|\.)*@(\w+\.)+[A-Za-z]*$"

for registration in registrationData:
    registration["valid"] = False
    registration["problems"] = ""

    emailValid = False
    passwordValid = False
    idValid = False
    secStringValid = False

    emailSearch = re.search(emailValidRegex, registration["email"])
    if emailSearch is None:
        pass
    elif emailSearch.group() == registration["email"]:
        emailValid = True

    passwordUpperCheck = re.findall(r"[A-Z]", registration["password"])
    passwordLowerCheck = re.findall(r"[a-z]", registration["password"])
    passwordNumberCheck = re.findall(r"[0-9]", registration["password"])
    passwordSpecialCheck = re.findall(r"\W", registration["password"])
    passwordLength = 8 <= len(registration["password"]) <= 15

    if len(passwordUpperCheck) >= 2 and len(passwordLowerCheck) >= 2 and len(passwordNumberCheck) > 1 and len(passwordSpecialCheck) > 1 and passwordLength:
        passwordValid = True

    secStringCheck = re.split(r"[A-Z]", registration["securityString"])[1:]
    secStringValid = [component for component in secStringCheck if re.search(r"[a-z]+", component).group() == component] == secStringCheck

    if re.search(r"^[0-9]{4}$", registration["id"]) is None:
        registration["id"] = re.sub(r"[1-9]*(?=0)", "", registration["id"])

    print(f"Registration ID {registration['id']}, {registration['name']} - Email Valid: {emailValid}, Password Valid: {passwordValid}, Security String Valid: {secStringValid}")