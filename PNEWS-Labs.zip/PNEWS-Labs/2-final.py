def returnScore(record):
    return record[3]


with open("2-dataset.txt", "r") as grades:
    gradeList = [record.rstrip("\n") for record in grades.readlines()]

freshmen = []
sophomores = []
juniors = []
seniors = []
allClassifications = [freshmen, sophomores, juniors, seniors]
classificationNames = ["FRESHMEN", "SOPHOMORES", "JUNIORS", "SENIORS"]

for grade in gradeList:
    splitRecord = grade.split()
    splitRecord[3] = int(splitRecord[3])
    if splitRecord[2] == "Freshman":
        freshmen.append(splitRecord)
    elif splitRecord[2] == "Sophomore":
        sophomores.append(splitRecord)
    elif splitRecord[2] == "Junior":
        juniors.append(splitRecord)
    elif splitRecord[2] == "Senior":
        seniors.append(splitRecord)

with open("2-dataset.txt", "a") as grades:
    grades.write("\n\n")
    for classification in enumerate(allClassifications):
        classification[1].sort(key=returnScore, reverse=True)
        grades.write(f"------ {classificationNames[classification[0]]} ------\n")
        for student in classification[1]:

            if student[3] >= 70:
                passFail = "Pass"
            else:
                passFail = "Fail"

            if student[3] < 60:
                letterGrade = "F"
            elif student[3] < 70:
                letterGrade = "D"
            elif student[3] < 80:
                letterGrade = "C"
            elif student[3] < 90:
                letterGrade = "B"
            elif student[3] <= 100:
                letterGrade = "A"

            grades.write(f"Rank {classification[1].index(student) + 1}: {student[1]}, {student[0]} - {student[3]} {letterGrade}, {passFail}\n")