# Output the text "Hello World" to the Python console
print("Hello World!")

# Take user's first name as user input and store it in variable
# Concatenate (combine) the text when printing!
userFirstName = input("What is your first name? ")
print("Hello World, " + userFirstName + "!")

# Python has many data types! Here are the basic ones that you'll be using most often!
dataTypeInteger = 8
dataTypeFloat = 8.1
dataTypeString = "More Python!"
dataTypeBoolean = False
dataTypeList = [8, "8.1"]
dataTypeDictionary = {"num1": 8, "num2": "8.1"}

# You can leverage "built-in methods" to manipulate the data stored in these variables.
# Let's set the entirety of dataTypeString to lowercase!
print("Before:", dataTypeString)  # Functionally, this concatenates the strings with an automatic space delimiter.
dataTypeString = dataTypeString.lower()  # The parentheses indicate that this is a function/method.
print(" ".join(["After:", dataTypeString]))
# Let's add a new item to the list!
print(dataTypeList)
dataTypeList.append(False)
print(dataTypeList)
# Let's add a new item to the dictionary!
print(dataTypeDictionary)
dataTypeDictionary["num3"] = 8.2
print(dataTypeDictionary)

# You can "cast" variables into other data types with built-in type methods!
wrongType = "8"
print(wrongType, type(wrongType), sep=" | ")  # type method takes value as an argument and returns the type of that object
rightType = int(wrongType)
print(rightType, type(rightType), sep=" | ")

# You can nest functions/methods! When evaluating behavior, evaluate closest to the inside, expanding outwards!
userAge = int(input("What is your age?"))  # Takes the value returned from the input method and runs it through int()

