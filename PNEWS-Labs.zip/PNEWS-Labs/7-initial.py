import netmiko
from time import sleep
import getpass

# Define IP addresses for CSRs
CSRIPs = []
try:
    with open("6-CSR.txt", "r") as CSRList:
        CSRIPs = [CSR.rstrip("\n") for CSR in CSRList.readlines()]
except FileNotFoundError:
    numCSRs = int(input("How many CSRs are there?: "))
    index = 0
    while index < numCSRs:
        CSRIPs.append(input(f"Provide the IP address of CSR {index + 1}: "))
        index += 1

# Create CSR SSH Sessions
username = input("Device Username: ")
password = getpass.getpass("Device Password: ")
CSRSessions = []
for CSR in CSRIPs:
    CSRSessions.append(netmiko.ConnectHandler(device_type="cisco_xe", ip=CSR, username=username, password=password))

CSRs = list(zip(CSRIPs, CSRSessions))

for CSR in CSRs:
    CSRNum = CSRs.index(CSR) + 1
    print(f"CSR-{CSRNum}: ")

    # Return show ip interface brief output
    print(CSR[1].send_command("show ip int br"))

    configurations = [["interface GigabitEthernet2", "no shutdown", f"ip address 10.0.{CSRNum}.1 255.255.255.0"],
                      ["interface Loopback0", f"ip address {CSRNum}.{CSRNum}.{CSRNum}.{CSRNum} 255.255.255.255"],
                      ["router ospf 1", "network 0.0.0.0 255.255.255.255 area 0"]]

    for configuration in configurations:
        operationalConfig = CSR[1].send_command(f"show run all | s {configuration[0]}").split("\n ")
        configSent = False

        for statement in configuration:
            if statement not in operationalConfig:
                CSR[1].send_config_set(configuration)
                print(f"Configuration {configuration} sent to CSR-{CSRNum}\n")
                configSent = True
                break

        if not configSent:
            print(f"Configuration {configuration} sent to CSR-{CSRNum}\n")

# Wait 60 seconds before running show commands to allow OSPF adjacencies to come up and converge
sleep(60)
# Return interface IP addresses, OSPF adjacency tables, and routing tables for each router
for CSR in CSRs:
    CSRNum = CSRs.index(CSR) + 1
    print(f"CSR-{CSRNum}: ")
    print(CSR[1].send_command("show ip int br"))
    print(CSR[1].send_command("show ip ospf neighbor"))
    print(CSR[1].send_command("show ip route"))
    CSR[1].disconnect()  # Kill SSH session

print("Finished!")