import netmiko
from time import sleep

""" DISCLAIMER: This is a deliberately suboptimal and inefficient script. This base script serves to
demonstrate the capabilities of Netmiko using basic Python constructs. In future labs, you will explore
and practice methods for optimizing the code below to create a more efficient script for managing devices via SSH. """

# Define IP addresses for CSRs
CSR1IP = "10.X.0.1"
CSR2IP = "10.X.1.2"
CSR3IP = "10.X.3.3"

# Create CSR SSH Sessions
CSR1Session = netmiko.ConnectHandler(device_type="cisco_xe", ip=CSR1IP, username="Admin", password="NterOne1!")
CSR2Session = netmiko.ConnectHandler(device_type="cisco_xe", ip=CSR2IP, username="Admin", password="NterOne1!")
CSR3Session = netmiko.ConnectHandler(device_type="cisco_xe", ip=CSR3IP, username="Admin", password="NterOne1!")

print("CSR-1: ")
# Return show ip interface brief output
print(CSR1Session.send_command("show ip int br"))
# Enter global config mode
CSR1Session.config_mode()
# Configure Loopback0 IP address
CSR1Session.send_command("interface Loopback0", expect_string=r"#")
CSR1Session.send_command("ip address 1.1.1.1 255.255.255.255", expect_string=r"#")
CSR1Session.send_command("exit", expect_string=r"#")
# Advertise networks in OSPF
CSR1Session.send_command("router ospf 1", expect_string=r"#")
CSR1Session.send_command("network 0.0.0.0 255.255.255.255 area 0", expect_string=r"#")
CSR1Session.exit_config_mode()

print("CSR-2: ")
# Return show ip interface brief output
print(CSR2Session.send_command("show ip int br"))
# Enter global config mode
CSR2Session.config_mode()
# Configure Loopback0 IP address
CSR2Session.send_command("interface Loopback0", expect_string=r"#")
CSR2Session.send_command("ip address 2.2.2.2 255.255.255.255", expect_string=r"#")
CSR2Session.send_command("exit", expect_string=r"#")
# Advertise networks in OSPF
CSR2Session.send_command("router ospf 1", expect_string=r"#")
CSR2Session.send_command("network 0.0.0.0 255.255.255.255 area 0", expect_string=r"#")
CSR2Session.exit_config_mode()


print("CSR-3: ")
# Return show ip interface brief output
print(CSR3Session.send_command("show ip int br"))
# Enter global config mode
CSR3Session.config_mode()
# Configure Loopback0 IP address
CSR3Session.send_command("interface Loopback0", expect_string=r"#")
CSR3Session.send_command("ip address 3.3.3.3 255.255.255.255", expect_string=r"#")
CSR3Session.send_command("exit", expect_string=r"#")
# Advertise networks in OSPF
CSR3Session.send_command("router ospf 1", expect_string=r"#")
CSR3Session.send_command("network 0.0.0.0 255.255.255.255 area 0", expect_string=r"#")
CSR3Session.exit_config_mode()

# Wait 60 seconds before running show commands to allow OSPF adjacencies to come up and converge
sleep(60)
# Return interface IP addresses, OSPF adjacency tables, and routing tables for each router
print("CSR-1:")
print(CSR1Session.send_command("show ip int br"))
print(CSR1Session.send_command("show ip ospf neighbor"))
print(CSR1Session.send_command("show ip route"))
CSR1Session.disconnect()  # Kill SSH session
print("CSR-2:")
print(CSR2Session.send_command("show ip int br"))
print(CSR2Session.send_command("show ip ospf neighbor"))
print(CSR2Session.send_command("show ip route"))
CSR2Session.disconnect()  # Kill SSH session
print("CSR-3:")
print(CSR3Session.send_command("show ip int br"))
print(CSR3Session.send_command("show ip ospf neighbor"))
print(CSR3Session.send_command("show ip route"))
CSR3Session.disconnect()  # Kill SSH session

print("Finished!")