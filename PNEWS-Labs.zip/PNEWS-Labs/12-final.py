import csv
import random


class StickPlayer:
    def __init__(self, playerNum, hand1, hand2):
        self.playerNum = playerNum
        self.name = self.getName()
        self.hand1 = hand1
        self.hand2 = hand2

    def getName(self):
        return input(f"Enter the name of player {self.playerNum}: ")

    def chooseOption(self):
        print("Choose from one of the following options:\n[1] Attack opponent hand\n[2] Rearrange hands\n[3] Forfeit")
        return int(input("Enter the number of the option you would like to choose (e.g., 1): "))

    def rearrangeHands(self, localHands):
        print("Note: Respond to the following questions with a number between 0-5, as needed. Note that the total number of extended fingers must remain the same and that you must change the combination of fingers on each hand..")
        print(f"Your hand arrangements are currently: {localHands}")
        firstHandValue = int(input("How many fingers should be extended on hand 1? "))
        secondHandValue = int(input("How many fingers should be extended on hand 2? "))

        if (firstHandValue + secondHandValue) == (localHands["hand1"] + localHands["hand2"]):
            if (firstHandValue, secondHandValue) != (localHands["hand1"], localHands["hand2"]):
                return (firstHandValue, secondHandValue)

        return None

    def attackOpponent(self, availableLocalHands, availableOpponentHands):
        print("Note: Respond to the following questions with either the number 1 or 2, as needed.")
        localHand = int(input(f"Which one of your hands would you like to attack from? You may choose from {availableLocalHands}: "))
        remoteHand = int(input(f"Which one of your opponent's hands would you like to attack? You may choose from {availableOpponentHands}: "))

        if f"hand{localHand}" not in availableLocalHands.keys() or f"hand{remoteHand}" not in availableOpponentHands.keys():
            return None
        else:
            newValue = availableOpponentHands[f"hand{remoteHand}"] + availableLocalHands[f"hand{localHand}"]
            if newValue >= 5:
                newValue = 0

            return (f"hand{remoteHand}", newValue)


player1 = StickPlayer(1, 1, 1)
player2 = StickPlayer(2, 1, 1)
players = [player1, player2]

random.shuffle(players)
turnCounter = 1
gameInfo = []

while True:
    gameEnd = False

    print(f"------ Round {str(turnCounter)} ------")

    for player in players:
        print(f"{player.name}'s turn!")

        if players.index(player) == 0:
            opponentID = 1
        elif players.index(player) == 1:
            opponentID = 0

        print(f"Your Hand 1: {player.hand1}")
        print(f"Your Hand 2: {player.hand2}")
        print(f"Opponent's Hand 1: {players[opponentID].hand1}")
        print(f"Opponent's Hand 2: {players[opponentID].hand2}")

        turnOption = player.chooseOption()
        if turnOption == 1:
            localHands = {}
            opponentHands = {}

            if player.hand1 != 0:
                localHands["hand1"] = player.hand1
            if player.hand2 != 0:
                localHands["hand2"] = player.hand2

            if players[opponentID].hand1 != 0:
                opponentHands["hand1"] = players[opponentID].hand1
            if players[opponentID].hand2 != 0:
                opponentHands["hand2"] = players[opponentID].hand2

            while True:
                attack = player.attackOpponent(localHands, opponentHands)
                if attack is not None:
                    if attack[0] == "hand1":
                        players[opponentID].hand1 = attack[1]
                    elif attack[0] == "hand2":
                        players[opponentID].hand2 = attack[1]
                    break
                else:
                    print("Select a valid option for attack!")
        elif turnOption == 2:
            while True:
                rearrange = player.rearrangeHands({"hand1": player.hand1, "hand2": player.hand2})
                if rearrange is not None:
                    player.hand1 = rearrange[0]
                    player.hand2 = rearrange[1]
                    break
                else:
                    print("Select a valid option for hand rearrangement!")
        elif turnOption == 3:
            player.hand1 = 0
            player.hand2 = 0

        if (localLost := (player.hand1 == 0 and player.hand2 == 0)) or (remoteLost := (players[opponentID].hand1 == 0 and players[opponentID].hand2 == 0)):
            gameEnd = True
            if localLost:
                winner = players[opponentID]
            if remoteLost:
                winner = player
            break

    if gameEnd:
        gameInfo.append(turnCounter)
        gameInfo.append(winner.playerNum)
        gameInfo.append(winner.name)
        gameInfo.append(winner.hand1)
        gameInfo.append(winner.hand2)

        print(f"Congratulations - {winner.name} won!")
        break
    else:
        turnCounter += 1

with open("12-gamedata.csv", "a") as gameData:
    csvWriter = csv.writer(gameData)
    csvWriter.writerow(gameInfo)