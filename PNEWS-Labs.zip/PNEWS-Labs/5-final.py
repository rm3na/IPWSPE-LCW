import netmiko
from time import sleep

# Define IP addresses for CSRs
CSRIPs = ["172.16.176.16", "172.16.176.17", "172.16.176.18"]

# Create CSR SSH Sessions
CSRSessions = [netmiko.ConnectHandler(device_type="cisco_xe", ip=CSRIPs[0], username="admin", password="MorePython"),
               netmiko.ConnectHandler(device_type="cisco_xe", ip=CSRIPs[1], username="admin", password="MorePython"),
               netmiko.ConnectHandler(device_type="cisco_xe", ip=CSRIPs[2], username="admin", password="MorePython")]

CSRs = list(zip(CSRIPs, CSRSessions))

for CSR in CSRs:
    CSRNum = CSRs.index(CSR) + 1
    print(f"CSR-{CSRNum}: ")
    # Return show ip interface brief output
    print(CSR[1].send_command("show ip int br"))]
    # Configure Loopback0 IP address
    CSR[1].send_config_set(["interface Loopback0", f"ip address {CSRNum}.{CSRNum}.{CSRNum}.{CSRNum} 255.255.255.255"])
    # Advertise networks in OSPF
    CSR[1].send_config_set(["router ospf 1", "network 0.0.0.0 255.255.255.255 area 0"])

# Wait 60 seconds before running show commands to allow OSPF adjacencies to come up and converge
sleep(60)
# Return interface IP addresses, OSPF adjacency tables, and routing tables for each router
for CSR in CSRs:
    CSRNum = CSRs.index(CSR) + 1
    print(f"CSR-{CSRNum}: ")
    print(CSR[1].send_command("show ip int br"))
    print(CSR[1].send_command("show ip ospf neighbor"))
    print(CSR[1].send_command("show ip route"))
    CSR[1].disconnect()  # Kill SSH session

print("Finished!")