import subprocess
import netmiko
import re


def checkLocalReachability(device):
    successfulReplies = None

    try:
        pingOutput = [line.decode() for line in subprocess.check_output(["ping", "-n", "4", device]).split(b"\r\n")]
        successfulReplies = [reply for reply in pingOutput if f"Reply from {device}" in reply]
    except subprocess.CalledProcessError:
        pass

    if successfulReplies is not None:
        if len(successfulReplies) > 0:
            return True

    return False


def checkRemoteReachability(address, session):
    pingStatus = session.send_command(f"ping {address}", read_timeout=180).split("\n")[2]

    if re.search(r"^(\.|!){2}!+$", pingStatus) is not None:
        return True

    return False


deviceAddresses = ["172.16.176.16", "172.16.176.17", "172.16.176.18", "192.0.2.1"]
for device in deviceAddresses:
    print(f"Local Reachability to {device}: {str(checkLocalReachability(device))}")


sessions = {}
loopbackIPs = {"R1": "1.1.1.1", "R2": "2.2.2.2", "R3": "3.3.3.3"}
for router in deviceAddresses[0:3]:
    sessions[f"R{deviceAddresses.index(router) + 1}"] = (netmiko.ConnectHandler(device_type="cisco_xe", ip=router, username="admin", password="MorePython"))

for loopbackRouter in loopbackIPs:
    loopbackIP = loopbackIPs[loopbackRouter]
    routersTested = list(loopbackIPs.keys())
    routersTested.remove(loopbackRouter)

    for router in routersTested:
        print(f"Remote Reachability from {router} to {loopbackIP}: {str(checkRemoteReachability(loopbackIP, sessions[router]))}")


for session in sessions.values():
    session.disconnect()