# Import Netmiko library - allow script to access methods within Netmiko
import netmiko
# Import the sleep method from the time library - allows script to wait X seconds before action
from time import sleep

# Create SSH session to CSR1000v with IP address of 10.254.254.1
sshSession = netmiko.ConnectHandler(device_type="cisco_xe", ip="10.254.254.1", username="admin", password="MorePython")

# Execute the "show ip interface brief" command within the SSH session; print the result of that command
print(sshSession.send_command("show ip interface brief"))

# Enter global configuration mode (equivalent to "configure terminal" or "config t")
sshSession.config_mode()
# Execute the "interface Loopback999" command within the SSH session
# expect_string=r"#" -> the script knows that the command is done executing when the SSH session returns a line
# with the # symbol in it (present in the prompt for the next command)
sshSession.send_command("interface Loopback999", expect_string=r"#")
# Execute the "ip address" command within the SSH session, under the Loopback999 interface configuration mode
sshSession.send_command("ip address 10.99.99.99 255.255.255.255", expect_string=r"#")
# Exits global configuration and returns to privileged EXEC prompt (equivalent to "end")
sshSession.exit_config_mode()

# Wait 15 seconds
sleep(15)
# Execute the "show ip interface brief" command within the SSH session; print the result of that command
print(sshSession.send_command("show ip interface brief"))
