"""
REQUIREMENTS FOR CHALLENGE 2:

1. The script must provide a method for two people to play the game of Stick; each player must be provided with two virtually simulated hands starting with one extended finger each. For simplicity, it is sufficient to represent a hand by a positive integer ranging from 1 to 5 representing the number of extended fingers.
2. The script must randomly pick the player that goes first in the game and in each round.
3. The script must provide a method for players to choose which hand of the opponent they would like to attack and from which available hand. The script must not allow a user to attack or attack from a hand that is eliminated (signified with an integer of 0).
4. The script must provide a method for players to recombine/modify the arrangement of their fingers, as long as the new combination maintains the same number of total active fingers between both hands as the old combination and the new combination is not the same as the old combination of extended fingers across a player’s hands.
5. The script must accurately handle elimination of a player’s hand from the game and conclude the game when one player’s hands are both eliminated from the game.
6. The script must save the results of the game to the 12-gamedata.csv file; the results must indicate the total turn count of the game, the winner of the game, and the remaining hand of the winner when the game concluded.
"""