from urllib3 import exceptions
from urllib3 import disable_warnings
from getpass import getpass
import requests
import json


class CSR:
    def __init__(self, hostname, mgmtIP, username, password):
        self.hostname = hostname
        self.mgmtIP = mgmtIP
        self.username = username
        self.password = password

        self.restSession = self.createRestSession()

    def createRestSession(self):
        session = requests.session()
        session.auth = (self.username, self.password)
        session.headers = {"Accept": "application/yang-data+json", "Content-Type": "application/yang-data+json"}
        session.verify = False

        return session

    def enforceHostname(self):
        hostname = self.restSession.get(url=f"https://{self.mgmtIP}/restconf/data/Cisco-IOS-XE-native:native/hostname")
        if hostname.status_code == 200:
            hostname = hostname.json()

        if hostname["Cisco-IOS-XE-native:hostname"] != self.hostname:
            body = {"Cisco-IOS-XE-native:hostname": self.hostname}
            replaceHostname = CSR.restSession.patch(url=f"https://{self.mgmtIP}/restconf/data/Cisco-IOS-XE-native:native/hostname",
                                  data=json.dumps(body))
            if replaceHostname.status_code == 204:
                print(f"Hostname has been successfully changed from {hostname['Cisco-IOS-XE-native:hostname']} to {self.hostname}")

    def addNewLoopback(self):
        loop999URL = f"https://{self.mgmtIP}/restconf/data/Cisco-IOS-XE-native:native/interface/Loopback=999"
        checkLoop999Exists = self.restSession.get(url=loop999URL)
        if checkLoop999Exists.status_code != 404:
            deleteLoop999 = self.restSession.delete(url=loop999URL)
            if deleteLoop999.status_code == 204:
                print(f"Loopback999 on {self.hostname} successfully deleted.")

        loop0URL = f"https://{self.mgmtIP}/restconf/data/Cisco-IOS-XE-native:native/interface/Loopback=0/ip/address/primary"
        getLoop0IP = self.restSession.get(url=loop0URL)
        if getLoop0IP.status_code == 200:
            loop0IP = getLoop0IP.json()["Cisco-IOS-XE-native:primary"]

        body = json.dumps({"Cisco-IOS-XE-native:Loopback": {"name": 999, "ip": {"address": {"primary": {"address": (loop0IP["address"] + "2"), "mask": loop0IP["mask"]}}}}})
        setLoop999IP = self.restSession.post(url=f"https://{self.mgmtIP}/restconf/data/Cisco-IOS-XE-native:native/interface", data=body)
        if setLoop999IP.status_code == 201:
            print(f"Successfully added Loopback999 with IP address {loop0IP['address'] + '2'}, mask {loop0IP['mask']}")

disable_warnings(exceptions.InsecureRequestWarning)

CSRs = []
username = input("Admin username: ")
password = getpass("Admin password: ")

for router in range(0, 3):
    hostname = f"PyLabCSR-{str(router + 1)}"
    mgmtIP = input(f"Management IP Address for {hostname}: ")
    CSRs.append(CSR(hostname=hostname, mgmtIP=mgmtIP, username=username, password=password))

for CSR in CSRs:
    CSR.enforceHostname()
    CSR.addNewLoopback()