import xml.etree.ElementTree as et


class TestInstance:
    def __init__(self, studentName, testName, definitionsFile):
        self.studentName = studentName
        self.testName = testName
        self.definitionsFile = definitionsFile
        self.testData = self.loadTestData()
        self.questions = self.extractTestQuestions()
        self.answerKey = self.extractAnswerKey()
        self.selectedAnswers = None
        self.percentageScore = None

    def loadTestData(self):
        try:
            with open(self.definitionsFile, "rb") as testData:
                return et.parse(testData)
        except FileNotFoundError:
            print("Test questions file not found.")
            exit(-1)
        except et.ParseError:
            print("Invalid XML file.")
            exit(-1)

    def extractTestQuestions(self):
        testQuestions = {}

        for question in self.testData.getroot().findall("./questions/"):
            testQuestions[question.attrib["num"]] = [question.attrib["text"], {}]
            for answer in question.iter("answer"):
                testQuestions[question.attrib["num"]][1][answer.attrib["letter"]] = answer.text

        return testQuestions

    def extractAnswerKey(self):
        answerKey = {}
        for keyEntry in self.testData.getroot().findall("./answerKey/"):
            answerKey[keyEntry.attrib["question"]] = keyEntry.attrib["answer"]

        return answerKey

    def takeTest(self):
        selectedAnswers = {}

        print(f"------ Student Name: {self.studentName}, Test: {self.testName} ------")
        for question in self.questions:
            questionText = self.questions[question][0]
            answerChoices = self.questions[question][1]

            print(f"Question {question}: {questionText}")
            for answer in answerChoices:
                print(f"{answer}. {answerChoices[answer]}")

            while True:
                selectedAnswer = input("Type in the letter for your answer choice (e.g., A): ").upper()
                if selectedAnswer in answerChoices.keys():
                    selectedAnswers[question] = selectedAnswer
                    break
                else:
                    print("Please re-type your answer. Ensure you type the letter of a valid answer choice.")

        self.selectedAnswers = selectedAnswers
        self.scoreTest()

    def scoreTest(self):
        correctQuestions = []
        for answer in self.selectedAnswers:
            if self.selectedAnswers[answer] == self.answerKey[answer]:
                correctQuestions.append(True)
            else:
                correctQuestions.append(False)

        percentageScore = f"{int((correctQuestions.count(True) / len(correctQuestions)) * 100)}%"

        self.percentageScore = percentageScore


student1 = TestInstance(studentName="Randy Jones", testName="Ultra Hard Exam", definitionsFile="10-testquestions.xml")
student2 = TestInstance(studentName="Sarah Woods", testName="Ultra Hard Exam", definitionsFile="10-testquestions.xml")

student1.takeTest()
student2.takeTest()

for student in [student1, student2]:
    print(f"{student.studentName} obtained a {student.percentageScore} on the following test: {student.testName}!")