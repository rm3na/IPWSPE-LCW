class Character:
    def __init__(self, charOrder):
        self.charOrder = charOrder
        self.name = self.formatInput(self.getCharacterName(), "capitalize-all")
        self.age = self.getCharacterAge()
        self.food = self.formatInput(self.getCharacterFavorite("food"), "lowercase")
        self.color = self.formatInput(self.getCharacterFavorite("color"), "lowercase")
        self.movie = self.formatInput(self.getCharacterFavorite("movie"), "capitalize-all")
        self.season = self.formatInput(self.getCharacterFavorite("season"), "capitalize-first")

    def getCharacterName(self):
        return input(f"What is the name of the {self.charOrder} character? ")

    def getCharacterAge(self):
        return int(input("What is this character's age? "))

    def getCharacterFavorite(self, thing):
        return input(f"What is this character's favorite {thing}? ")

    def formatInput(self, value, operation):
        if operation == "capitalize-all":
            return " ".join([word.capitalize() for word in value.split()])
        elif operation == "capitalize-first":
            return value.capitalize()
        elif operation == "lowercase":
            return value.lower()

    def printSentenceStem(self):
        if self.season in ["Fall", "Winter"]:
            attire = "a jacket"
        elif self.season in ["Spring", "Summer"]:
            attire = "shorts"

        print(f"{self.name} is a {self.age} year old that enjoys eating {self.color} {self.food} while watching {self.movie} with {attire} on.")


char1 = Character("first")
char2 = Character("second")
char3 = Character("third")
characters = [char1, char2, char3]

for character in characters:
    character.printSentenceStem()