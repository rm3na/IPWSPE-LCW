# Ask user "What is the name of the first character? "; store this value in char1Name
# Ask user "What is this character's favorite food? "; store this value in char1Food
# Ask user "What is this character's favorite color? "; store this value in char1Color
# Ask user "What is this character's favorite movie? "; store this value in char1Movie
# Ask user "What is this character's age? "; store this value as an integer in char1Age (assume valid integer as input)
# Ask user "What is this character's favorite season? "; store this value in char1Season

# Ask user "What is the name of the second character? "; store this value in char2Name
# Ask user "What is this character's favorite food? "; store this value in char2Food
# Ask user "What is this character's favorite color? "; store this value in char2Color
# Ask user "What is this character's favorite movie? "; store this value in char2Movie
# Ask user "What is this character's age? "; store this value as an integer in char2Age (assume valid integer as input)
# Ask user "What is this character's favorite season? "; store this value in char2Season

# Ask user "What is the name of the third character? "; store this value in char3Name
# Ask user "What is this character's favorite food? "; store this value in char3Food
# Ask user "What is this character's favorite color? "; store this value in char3Color
# Ask user "What is this character's favorite movie? "; store this value in char3Movie
# Ask user "What is this character's age? "; store this value as an integer in char3Age (assume valid integer as input)
# Ask user "What is this character's favorite season? "; store this value in char3Season

# Capitalize the first letter of the words of the value of char1Name
# Lowercase the value of char1Food
# Lowercase the value of char1Color
# Capitalize the first letter of the words of the value of char1Movie
# Capitalize the first letter of the first word of the value of char1Season

# Capitalize the first letter of the words of the value of char2Name
# Lowercase the value of char2Food
# Lowercase the value of char2Color
# Capitalize the first letter of the words of the value of char2Movie
# Capitalize the first letter of the first word of the value of char2Season

# Capitalize the first letter of the words of the value of char3Name
# Lowercase the value of char3Food
# Lowercase the value of char3Color
# Capitalize the first letter of the words of the value of char3Movie
# Capitalize the first letter of the first word of the value of char3Season

# If character 1's favorite season is either Fall or Winter, print the following:
# "<name> is a <age> year old that enjoys eating <color> <food> while watching <movie> with a jacket on."
# If the above is not true and character 1's favorite season is either Spring or Summer, print the following:
# "<name> is a <age> year old that enjoys eating <color> <food> while watching <movie> with shorts on."
# If character 2's favorite season is either Fall or Winter, print the following:
# "<name> is a <age> year old that enjoys eating <color> <food> while watching <movie> with a jacket on."
# If the above is not true and character 2's favorite season is either Spring or Summer, print the following:
# "<name> is a <age> year old that enjoys eating <color> <food> while watching <movie> with shorts on."
# If character 3's favorite season is either Fall or Winter, print the following:
# "<name> is a <age> year old that enjoys eating <color> <food> while watching <movie> with a jacket on."
# If the above is not true and character 3's favorite season is either Spring or Summer, print the following:
# "<name> is a <age> year old that enjoys eating <color> <food> while watching <movie> with shorts on."