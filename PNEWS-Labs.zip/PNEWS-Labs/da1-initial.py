# Output the text "Hello World" to the Python console

# Take user's first name as user input and store it in variable

# Concatenate (combine) the text when printing!

# Python has many data types! Here are the basic ones that you'll be using most often!

# You can leverage "built-in methods" to manipulate the data stored in these variables.

# Let's set the entirety of dataTypeString to lowercase!

# Let's add a new item to the list!

# Let's add a new item to the dictionary!

# You can "cast" variables into other data types with built-in type methods!

# You can nest functions/methods! When evaluating behavior, evaluate closest to the inside, expanding outwards!


