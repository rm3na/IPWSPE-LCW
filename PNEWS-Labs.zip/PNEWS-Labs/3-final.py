import csv
import json
import xml.etree.ElementTree as et

with open("3-animaldefinitions.json", "r") as animalList:
    animals = json.load(animalList)

animalNames = animals["animalDefinitions"]

with open("3-fruitdefinitions.xml", "r") as fruitList:
    fruits = et.parse(fruitList)

fruitNames = []

for fruit in fruits.getroot().iter("fruit"):
    fruitNames.append(fruit.attrib["name"])

with open("3-dataset.csv", "r") as data:
    sampleData = [row for row in csv.reader(data)]
    for item in sampleData:
        item[1] = item[1].strip()

for record in sampleData:
    if record[1] == "unknown":
        if record[0] in animalNames:
            record[1] = "animal"
        elif record[0] in fruitNames:
            record[1] = "fruit"
        else:
            record[1] = "invalid"

with open("3-dataset.csv", "w", newline='') as newData:
    writer = csv.writer(newData)
    writer.writerows(sampleData)