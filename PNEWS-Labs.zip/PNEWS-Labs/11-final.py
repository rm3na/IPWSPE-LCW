import json
import csv

class Store:
    def __init__(self, cart, storeName, storeItems):
        self.cart = cart
        self.totalCartPrice = 0.00
        self.storeName = storeName
        self.storeItems = storeItems

        self.addNetPrice()

    def addNetPrice(self):
        for item in self.storeItems:
            self.storeItems[item]["netPrice"] = float(self.storeItems[item]["price"]) * (1 - float(self.storeItems[item]["discountPercentage"]) / 100) * 1.05

    def displayCatalog(self):
        print("------ Store Catalog ------")
        for item in self.storeItems:
            print(f"Item ID {item}: {self.storeItems[item]['name']}, ${self.storeItems[item]['netPrice']:.2f}, Quantity: {self.storeItems[item]['availableQuantity']}")

    def displayShoppingCart(self):
        print("------ Shopping Cart ------")
        if len(self.cart) == 0:
            print("Empty shopping cart - no items to display.")
            return None
        for item in self.cart:
            print(f"Item ID {item}: {self.storeItems[item]['name']}, Quantity: {self.cart[item]}, Price: ${self.storeItems[item]['netPrice']:.2f}")

        print(f"Total Cart Price: ${self.totalCartPrice:.2f}")

    def addItemsToCart(self, itemID, quantity):
        availableQuantity = int(self.storeItems[itemID]["availableQuantity"])
        try:
            if availableQuantity >= quantity + self.cart[itemID]:
                self.cart[itemID] += quantity
                self.totalCartPrice += self.storeItems[itemID]["netPrice"] * quantity
                self.storeItems[itemID]["availableQuantity"] = str(availableQuantity - quantity)
                return None
        except KeyError:
            if availableQuantity >= quantity:
                self.cart[itemID] = quantity
                self.totalCartPrice += self.storeItems[itemID]["netPrice"] * quantity
                self.storeItems[itemID]["availableQuantity"] = str(availableQuantity - quantity)
                return None

        print("Failed to add item to cart: insufficient quantity.")

    def removeItemsFromCart(self, itemID):
        self.cart.pop(itemID)

    def collectPurchaserInformation(self):
        buyerName = input("Enter your full name: ")
        buyerEmail = input("Enter your e-mail address: ")
        buyerPhone = input("Enter your phone number: ")
        buyerCountry = input("Enter your country code (e.g., US, CA, NZ, AU): ")
        buyerAddress = input("Enter your full address on one line: ")

        with open("11-shopRequests.csv", "a") as requestRecord:
            csvWriter = csv.writer(requestRecord)
            csvWriter.writerow([buyerName, buyerEmail, buyerPhone, buyerCountry, buyerAddress, self.cart, f"${self.totalCartPrice:.2f}"])

        print("Thank you for your purchase!")

        with open("11-shopItems.json", "w") as shopData:
            json.dump({"storeProperties": {"storeName": self.storeName}, "items": self.storeItems}, shopData)
            return True


with open("11-shopItems.json", "r") as data:
    storeDetails = json.load(data)

storeObject = Store(cart={}, storeName=storeDetails["storeProperties"]["storeName"], storeItems=storeDetails["items"])

while True:
    print("---------------------------------------------------------")
    print(f"---------- WELCOME TO {storeObject.storeName} ----------")

    print("Pick from the following options:\n[1] Display catalog\n[2] View shopping cart\n[3] Add item to shopping cart\n[4] Remove item from shopping cart\n[5] Complete purchase\n[6] Exit")
    selection = int(input("Enter the number associated with your desired option: "))

    if selection == 1:
        storeObject.displayCatalog()
    elif selection == 2:
        storeObject.displayShoppingCart()
    elif selection == 3:
        storeObject.displayCatalog()
        addItem = input("Type the ID of the item that you would like to add to your cart: ")
        itemQuantity = int(input("How many of this item would you like? "))

        storeObject.addItemsToCart(addItem, itemQuantity)
    elif selection == 4:
        storeObject.displayShoppingCart()
        removeItem = input("Type the ID of the item that you would like to remove from your cart: ")

        storeObject.removeItemsFromCart(removeItem)
    elif selection == 5:
        if len(storeObject.cart) > 0:
            if storeObject.collectPurchaserInformation():
                break
    elif selection == 6:
        exit(0)
